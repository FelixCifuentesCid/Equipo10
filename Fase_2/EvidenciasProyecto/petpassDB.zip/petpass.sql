-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 01-07-2025 a las 02:30:15
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `petpass`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clinica`
--

CREATE TABLE `clinica` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `direccion` varchar(150) NOT NULL,
  `telefono` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `documento`
--

CREATE TABLE `documento` (
  `id` int(11) NOT NULL,
  `mascota_id` int(11) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `descripccion` text DEFAULT NULL,
  `fecha_emision` date NOT NULL,
  `archivo_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dueno`
--

CREATE TABLE `dueno` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `correo` varchar(255) DEFAULT NULL,
  `telefono` varchar(255) DEFAULT NULL,
  `tipo` varchar(255) DEFAULT NULL,
  `contrasena` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `dueno`
--

INSERT INTO `dueno` (`id`, `nombre`, `correo`, `telefono`, `tipo`, `contrasena`) VALUES
(1, 'Jonny', 'stickdrawn@gmail.com', '+569123456', '', NULL),
(3, 'are', 'stickdrawn@puesil.com', '+5691234534', '', NULL),
(4, 'tim', 'tim@prueba.com', '+5692345243', '', NULL),
(5, 'Prueba', 'prueba@prueba.com', '+56932948653', '', NULL),
(6, 'Martha', 'test@test.com', '+5693652836', '', NULL),
(7, 'Jhoa', '2test@test.com', '+5683647382', '', NULL),
(8, 'Thiago', '3test@gmail.com', '+56784789045', '', NULL),
(9, 'Roberto', 'rober@gmail.com', '+56932867645', '', NULL),
(10, 'Banmedica', 'Banmedic@gmail.com', '+5692345243', 'CLINICA', 'banmedic12.'),
(11, 'Alfonso', 'prueba2@gmail.com', '+5683647382', 'DUEÑO', 'Prueba2.'),
(12, 'Clinica Davila', 'Davila@clincia.com', '+56932948653', 'CLINICA', 'DavilaCon');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mascota`
--

CREATE TABLE `mascota` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `especie` varchar(255) DEFAULT NULL,
  `edad` int(11) NOT NULL,
  `vacunas` varchar(255) DEFAULT NULL,
  `dueno_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `mascota`
--

INSERT INTO `mascota` (`id`, `nombre`, `especie`, `edad`, `vacunas`, `dueno_id`) VALUES
(1, 'Princesa', 'Perro', 12, 'Sí', 1),
(2, 'Prince ', 'Gato', 12, 'Sí', 7),
(3, 'loco', 'Perro', 23, 'Sí', 7),
(4, 'Pez', 'Perro', 23, 'Sí', 8),
(5, 'lobo', 'Perro', 21, 'Sí', 8),
(6, 'sound', 'Perro', 2, 'Sí', 1),
(7, 'toby', 'Gato', 1, 'Sí', 9),
(8, 'Princess', 'Gato', 5, 'Sí', 11);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro_vacuna`
--

CREATE TABLE `registro_vacuna` (
  `id` int(11) NOT NULL,
  `mascota_id` int(11) NOT NULL,
  `vacuna_id` int(11) NOT NULL,
  `fecha_aplicacion` date NOT NULL,
  `observaciones` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vacuna`
--

CREATE TABLE `vacuna` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL COMMENT 'nombre de la vacuna',
  `descripcion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `visita_veterinaria`
--

CREATE TABLE `visita_veterinaria` (
  `id` int(11) NOT NULL,
  `mascota_id` int(11) NOT NULL,
  `clinica_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `motivo` varchar(100) NOT NULL,
  `diagnostico` text NOT NULL,
  `tratamiento` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clinica`
--
ALTER TABLE `clinica`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `documento`
--
ALTER TABLE `documento`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_mascota_id` (`mascota_id`);

--
-- Indices de la tabla `dueno`
--
ALTER TABLE `dueno`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `correo_unico` (`correo`);

--
-- Indices de la tabla `mascota`
--
ALTER TABLE `mascota`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_dueno_id` (`dueno_id`);

--
-- Indices de la tabla `registro_vacuna`
--
ALTER TABLE `registro_vacuna`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_mascota_id` (`mascota_id`),
  ADD KEY `fk_vacuna_id` (`vacuna_id`);

--
-- Indices de la tabla `vacuna`
--
ALTER TABLE `vacuna`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `visita_veterinaria`
--
ALTER TABLE `visita_veterinaria`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_mascota_id` (`mascota_id`),
  ADD KEY `fk_clinica_id` (`clinica_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clinica`
--
ALTER TABLE `clinica`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `documento`
--
ALTER TABLE `documento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `dueno`
--
ALTER TABLE `dueno`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `mascota`
--
ALTER TABLE `mascota`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `registro_vacuna`
--
ALTER TABLE `registro_vacuna`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `vacuna`
--
ALTER TABLE `vacuna`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `visita_veterinaria`
--
ALTER TABLE `visita_veterinaria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `mascota`
--
ALTER TABLE `mascota`
  ADD CONSTRAINT `fk_dueno_id` FOREIGN KEY (`dueno_id`) REFERENCES `dueno` (`id`);

--
-- Filtros para la tabla `registro_vacuna`
--
ALTER TABLE `registro_vacuna`
  ADD CONSTRAINT `fk_mascota_id` FOREIGN KEY (`mascota_id`) REFERENCES `mascota` (`id`),
  ADD CONSTRAINT `fk_vacuna_id` FOREIGN KEY (`vacuna_id`) REFERENCES `vacuna` (`id`);

--
-- Filtros para la tabla `visita_veterinaria`
--
ALTER TABLE `visita_veterinaria`
  ADD CONSTRAINT `fk_clinica_id` FOREIGN KEY (`clinica_id`) REFERENCES `clinica` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
